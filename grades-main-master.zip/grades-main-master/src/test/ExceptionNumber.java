package test;

public class ExceptionNumber extends Exception{

    private String message;

    public ExceptionNumber(String message) {
        super(message);
    }
}
